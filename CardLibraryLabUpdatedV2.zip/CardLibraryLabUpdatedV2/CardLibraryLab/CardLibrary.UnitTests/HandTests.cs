﻿using FluentAssertions;

namespace CardLibrary.UnitTests
{
    [TestClass]
    public class HandTests
    {
        [TestMethod]
        public void TestHandAddition()
        {
            // Arrange
            Hand testHand = new Hand();
            Card testCard = new Card(FaceValue.Ace, Suit.Diamonds);

            // Act
            testHand.Add(testCard);

            // Assert
            Assert.IsNotNull(testHand.Cards);
            Assert.IsTrue(testHand.Cards.Count == 1);
        }

        [TestMethod]
        public void ClearHand()
        {
            // Arrange
            Hand testHand = new Hand();
            Card testCard = new Card(FaceValue.Ace, Suit.Diamonds);
            Card testCard2 = new Card(FaceValue.Four, Suit.Hearts);

            // Act
            testHand.Add(testCard);
            testHand.Add(testCard2);
            testHand.Clear();

            // Assert
            Assert.IsNotNull(testHand.Cards);
            Assert.IsTrue(testHand.Cards.Count == 0);
        }
    }
}
