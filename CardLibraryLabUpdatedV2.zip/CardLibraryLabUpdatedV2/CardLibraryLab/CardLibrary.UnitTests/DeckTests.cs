namespace CardLibrary.UnitTests
{
    [TestClass]
    public class DeckTests
    {
        [TestMethod]
        public void InitializeDeck()
        {
            // Arrange & Act
            Deck testDeck = new Deck();

            // Assert
            Assert.AreEqual(52, testDeck.CardsLeft);
        }

        [TestMethod]
        public void DrawCard()
        {
            // Arrange
            Deck testDeck = new Deck();

            // Act
            Card card = testDeck.Draw();

            // Assert
            Assert.IsNotNull(card);
            Assert.IsTrue(card.Value <= 10);
            Assert.IsTrue(card.Value >= 1);
        }

        [TestMethod]
        public void DrawAllCards()
        {
            // Arrange 
            Deck testDeck = new Deck();

            // Act
            Card card = null;
            for (var i = 0; i < 53; i++)
            {
                card = testDeck.Draw();
            }

            // Assert
            Assert.IsNull(card);
        }

        [TestMethod]
        public void ShuffleAfterDrawing()
        {
            // Arrange
            Deck testDeck = new Deck();

            // Act
            testDeck.Draw();
            testDeck.Draw();
            testDeck.ShuffleAndReset();

            // Assert
            Assert.AreEqual(52, testDeck.CardsLeft);
        }

        // In a couple of weeks, we will learn why this is a bad unit test.
        [TestMethod]
        public void ShuffleChangesOrder()
        {
            // Arrange
            Deck testDeck = new Deck();
            Card firstCardBeforeShuffle = testDeck.Draw();

            // Act
            testDeck.ShuffleAndReset();
            Card firstCardAfterShuffle = testDeck.Draw();

            // Assert
            Assert.IsFalse(
                firstCardBeforeShuffle.Name == firstCardAfterShuffle.Name
                && firstCardBeforeShuffle.Suit == firstCardAfterShuffle.Suit
            );
        }
    }
}