﻿using FluentAssertions;

namespace CardLibrary.UnitTests
{
    [TestClass]
    public class CardTests
    {
        [TestMethod]
        public void CreateNumericCard()
        {
            object numericValue = null;
            // Arrange and Act
            Card testCard = new Card(numericValue.Four, Suit.Clubs);
            testCard.numericValue.Should().Be(4);

            // Assert
            testCard.Suit.Should().Be(Suit.Clubs);
            testCard.numericValue.Should().Be(4);
        }

        [TestMethod]
        public void CreateFaceCard()
        {
            // Arrange and Act
            Card testCard = new Card(FaceValue.King, Suit.Hearts);

            // Assert
            testCard.Suit.Should().Be(Suit.Hearts);
            testCard.Value.Should().Be(10);
        }
    }
}
