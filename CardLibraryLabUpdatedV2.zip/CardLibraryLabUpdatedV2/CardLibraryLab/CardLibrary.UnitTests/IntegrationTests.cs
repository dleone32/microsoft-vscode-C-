﻿namespace CardLibrary.UnitTests
{
    [TestClass]
    public class IntegrationTests
    {
        [TestMethod]
        public void PlayRound()
        {
            // Arrange
            Deck cardDeck = new Deck();
            Hand player1 = new Hand();
            Hand player2 = new Hand();

            // Act & Assert
            player1.Add(cardDeck.Draw());
            player2.Add(cardDeck.Draw());

            player1.Add(cardDeck.Draw());
            player2.Add(cardDeck.Draw());

            player1.Add(cardDeck.Draw());
            player2.Add(cardDeck.Draw());

            player1.Add(cardDeck.Draw());
            player2.Add(cardDeck.Draw());

            player1.Add(cardDeck.Draw());
            player2.Add(cardDeck.Draw());

            Assert.IsTrue(player2.Cards.Count == 5);
            Assert.IsTrue(player1.Cards.Count == 5);
            Assert.IsTrue(player1.Cards[0].Value > 0);
            Assert.IsTrue(player2.Cards[0].Value > 0);

            Assert.IsTrue(cardDeck.CardsLeft == 42);

            player1.Clear();
            player2.Clear();
            cardDeck.ShuffleAndReset();

            Assert.IsTrue(player2.Cards.Count == 0);
            Assert.IsTrue(player1.Cards.Count == 0);
            Assert.IsTrue(cardDeck.CardsLeft == 52);
        }
    }
}
