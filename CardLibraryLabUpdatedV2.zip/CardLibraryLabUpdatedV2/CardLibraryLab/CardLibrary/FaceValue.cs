﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardLibrary
{
    public static class FaceValue
    {
        public static string Ace { get; } = "Ace";
        public static string King { get; } = "King";
        public static string Queen { get; } = "Queen";
        public static string Jack { get; } = "Jack";
        public static string Ten { get; } = "Ten";
        public static string Nine { get; } = "Nine";
        public static string Eight { get; } = "Eight";
        public static string Seven { get; } = "Seven";
        public static string Six { get; } = "Six";
        public static string Five { get; } = "Five";
        public static string Four { get; } = "Four";
        public static string Three { get; } = "Three";
        public static string Two { get; } = "Two";
    }

    public static class NumericValue
    {
        public static int Ace { get; } = 1;
        public static int Four { get; } = 4;
    }
}

