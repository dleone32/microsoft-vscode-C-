﻿namespace CardLibrary
{
    public partial class Card
    {
        enum value 
        {
            Ace = 1,
            King = 10,
            Four = 4,
            return Value;
        }
    }
}
