﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardLibrary
{
    public static class Suit
    {
        public static string Clubs { get; } = "Clubs";
        public static string Spades { get; } = "Spades";
        public static string Hearts { get; } = "Hearts";
        public static string Diamonds { get; } = "Diamonds";
    }
}
