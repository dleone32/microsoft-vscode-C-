﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardLibrary
{
    public class Card
    {
        public object numericValue;
     
        



        public string Suit { get; }
        public string Name { get; }
        public int Value { get; }
        
        





        public Card(string faceValue, string suit, int numericValue)
        {
           
            this.Name = faceValue;
            this.Suit = suit;
            this.numericValue = Value;
            

           
        }

        public Card(object numericValue)
        {
            numericValue  null;
        }
    }

}
