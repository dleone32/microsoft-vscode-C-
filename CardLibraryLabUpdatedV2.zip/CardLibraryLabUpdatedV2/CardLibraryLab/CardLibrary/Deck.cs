﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardLibrary
{
    public class Deck
    {
        private List<Card> cards;

        public object deck;

        private object totalCards;

        public Deck()
        {
            this.cards = new List<Card>();
            
        }

        public int CardsLeft {get;}

        public Card Draw()
        {
            // Remove a card from the deck, decrementing the total number of cards in the deck by 1
            // Arrange
           
            // Remove a card from the deck, decrementing the total number of cards in the deck by 1

            
        }

        public void ShuffleAndReset()
        {
            
        }
    }
}
