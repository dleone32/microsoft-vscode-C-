# ITEC 2585 Week 2 Lab: Classes and Simple Object Construction

## Lab Description

The most common deck of playing cards has 52 cards and 4 suits. ([Wikipedia Background](https://en.wikipedia.org/wiki/Standard_52-card_deck)) It can be used in a wide variety of different games across a large number of countries. Most card games predate computers, but there have been many software programs written to allow users to play card games virtually or analyze them. To do this, the components of the card deck has to be represented virtually and operations must be able to be performed.

In this lab we will implement basic functionality for two players and a deck of cards. We will model a deck and the associated operations as simple classes. These classes provide building blocks that could then be used to construct more complex card games.

## Lab Requirements

These are the things that must be true about the deck and cards:

- A *deck* consists of 52 *cards*
- A deck has four *suits*: hearts, diamonds, clubs, and spades
- A deck has 13 *face values*: Ace, 2, 3, 4, 5, 6, 7, 8, 9, 10, Jack, Queen, King
- Each card has a face value (name), a suit, and a numeric value associated with it
- A card with a face value of a number, has the same number as its numeric value (e.g. the 3 of Clubs has a numeric value of 3)
- A Jack, Queen, or King has a numeric value of 10
- An Ace has a numeric value of 1
- A *hand* is a collection of cards held by a player

These are the operations that must be supported:

- *Drawing* a card from the deck: Select the top card in the deck, removing it from the deck
- Adding a card to a player's hand
- *Shuffling* a deck: Add all cards back to the deck and randomize the order
- Removing all cards from a player's hand

## Lab Instructions

I have provided a test suite for the operations that are expected, which also gives strong hints about class structure and organization. At the start of the lab, the solution will not build, and all tests will fail. As you implement the classes for the card deck described above, the project will eventually build and all tests should pass. You should feel free to rename or reorganize any of the suggested class names or operations if you wish. The functionality described by each test must exist, but you can change the implementation as you see fit.

- Think: What classes would describe a card deck?
- Think: What properties, fields, and methods might those classes have?
- Go to Module 2 in D2L and download CardLibraryTests.zip
- Unzip the file and open the solution in Visual Studio
- Currently the solution does not build, and all tests fail
- Examine the CardLibrary.UnitTests project
    - This project contains 4 test files that will all pass when the lab is complete
- Implement the Deck, Card, and Hand classes
- The solution should build and the tests should pass
- Fill in the below questions
- Upload your completed solution with answers to the questions as a single .zip file

### Lab Questions

1. In the `InitializeDeck` test, we check the value of `testDeck.CardsLeft`. Is `CardsLeft` a property or a field?
2. Could any of these classes or methods on the classes be implemented as `static`?
3. In your implementation, how are the properties of classes constrained so that a card can only be created with the allowed values for suit and face value?
4. What class would be a good candidate for implementation as a `record`? Why?
5. How many of your classes have custom constructors? How many have default constructors?

## Lab Grading

The lab overall will be worth 50 points.

- 30 points from a solution that builds and passes tests
- 15 points from answering the lab questions above
- 5 points from the quality and organization of the code
